const mysql = require("mysql2/promise");

const pool = mysql.createPool({
  host: 'bproject2.intanciptaperdana.id',
  port: 3306,
  user: 'inty8713_divisi_peralatan',
  password: '1Sampai9@',
  database: 'inty8713_peralatan_project2',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  charset: "utf8mb4",
  dateStrings: true,   // ← Kembalikan DATE/DATETIME sebagai string "YYYY-MM-DD"
  timezone: '+07:00',  // ← WIB (UTC+7) — sesuai timezone MySQL server lokal
});

// Test koneksi saat startup
pool
  .getConnection()
  .then((conn) => {
    console.log(
      "✅ MySQL connected to database: peralatanmwt (localhost)",
    );
    conn.release();
  })
  .catch((err) => {
    console.error("❌ MySQL connection failed:", err.message);
  });

module.exports = pool;
